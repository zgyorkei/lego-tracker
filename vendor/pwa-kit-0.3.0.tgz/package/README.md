# pwa-kit

The PWA pieces the personal apps share, in one library, so each piece is
written and fixed once and every new build starts from the same base. Each part
is its own subpath export: an app imports only the parts it uses.

Extracted from SmakMal's PWA (SM.PWA: the manifest, the worker, the install
entry, offline read and edit, the share target, the reminders) and checked
against BrickBudget's (budget-tracker) and Brick Tracker's (lego-tracker) own
`public/manifest.webmanifest` and `public/sw.js`, so it covers all three. No app
uses it yet: each switches over in an item of its own.

## Parts

| Import | Holds | Runs in |
| --- | --- | --- |
| `pwa-kit` | `PwaConfig`, `definePwa`: the app's PWA in one object | anywhere |
| `pwa-kit/manifest` | the manifest and its quick actions, the head tags, the config's checks, the quick action candidates from the app's code | anywhere |
| `pwa-kit/vite` | the Vite plugin: manifest written, head tags added, worker bundled with the build's file list | the build (Node) |
| `pwa-kit/sw` | the service worker: precache, offline navigations, the update flow, run-time hosts, the share target, notifications | the worker |
| `pwa-kit/update` | registering the worker, the "A new version is ready" store | the page |
| `pwa-kit/install` | the install entry: the browser's dialog, the iPhone and iPad steps | the page |
| `pwa-kit/offline` | online or not, a write not waited on offline, actions that need a connection | the page |
| `pwa-kit/share` | the share target's page side (and the worker's, which `pwa-kit/sw` calls) | page and worker |
| `pwa-kit/push` | notifications: support, permission, subscribe, unsubscribe | the page |
| `pwa-kit/push/server` | sending them: Web Push with VAPID and the encrypted payload, the subscription store (in memory, on Firestore), a push to every device | the server (Node) |
| `pwa-kit/session` | a sign-in that lasts past an hour: the Google session's page side, Firebase's route in an installed app | the page |
| `pwa-kit/session/server` | the Google session's server side: the sealed cookie, the four routes | the server (Node) |
| `pwa-kit/nav` | the main navigation's state: the mode by width, what shows and what goes into More, the active destination, the installed window's back control | the page |

Vite is an optional peer dependency (only `pwa-kit/vite` loads it). The kit
has no UI: the install entry, the update bar, the offline line and the
navigation bar are the app's own, in its look and language; the kit gives them
their state.

## The config

One object, `pwa.config.ts` beside the app's `vite.config.ts`; everything else
reads it.

```ts
import { definePwa } from 'pwa-kit';

export default definePwa({
  app: 'smakmal',                     // cache names: smakmal-shell-<version>, smakmal-share, smakmal-runtime
  name: 'SmakMål',
  shortName: 'SmakMål',               // 12 characters or fewer read whole
  description: "Your household's kitchen, meal planner and shopping list.",
  lang: 'en',
  themeColor: '#b5a48d',
  backgroundColor: '#e8e2df',
  icons: [
    { src: '/icon-192.png', size: 192 },
    { src: '/icon-512.png', size: 512 },
    { src: '/icon-maskable-512.png', size: 512, purpose: 'maskable' },
  ],
  appleTouchIcon: '/apple-touch-icon.png',
  quickActions: [
    { name: 'Planner', description: "Plan the week's meals", url: '/planner', icon: '/shortcut-planner-96.png' },
    { name: 'Shopping list', shortName: 'Shopping', url: '/shopping', icon: '/shortcut-shopping-96.png' },
  ],
  shareTarget: { method: 'post', action: '/share-receipt', opens: '/shopping?shared=receipt', files: { field: 'receipt', accept: ['image/*'] } },
});
```

`checkPwaConfig` (and the plugin, which stops the build on an error) checks it:
the 192 and 512 px "any" icons (no install offer without them), colours as
hex, the start URL inside the scope, every quick action and the share target
on a path of this app inside its scope, each quick action's route once. It
warns past four quick actions, on a short name over 12 characters and on a
quick action with no icon.

### Quick actions: asked of the user

A quick action is a manifest shortcut: a long press on the installed app's
icon (Android, desktop Chromium; iPhone and iPad show none) lists them, and
each opens one route. `quickActions` has no default: the config must state
them, `[]` when the user wants none, so adopting the kit always asks.

The question is asked from the app's purpose and its code. `npx pwa-kit routes`
lists the routes the code names (React Router's `path`, `to`, `navigate()`,
`href`), the most named first, without parameters, the API, files and tests:

```sh
npx pwa-kit routes src            # add --json for the list as data
```

The candidates and what the app is for go to the user as one choice (Android
shows four); the user's pick goes into `quickActions`. An app that switches
views by state or query (BrickBudget: `?view=wishlist`) has no fixed routes in
its code: there the quick actions are named by hand, as a route with a query if
the page reads one.

## The build (`pwa-kit/vite`)

```ts
import { pwa } from 'pwa-kit/vite';
import config from './pwa.config';

export default defineConfig({
  plugins: [react(), pwa({ config, worker: path.resolve(__dirname, 'src/sw.ts'), skip: [/^kitchen-renders\//] })],
});
```

- **The manifest** is written to `manifest.webmanifest` in the build and served
  at `/manifest.webmanifest` by the dev server. An app's own
  `public/manifest.webmanifest` stops the build, so the two never disagree.
- **The head tags** the page lacks are added: the manifest link, `theme-color`,
  `apple-touch-icon` and the `apple-mobile-web-app-*` tags iPhone and iPad read
  instead of the manifest. A tag the page already has (same `rel` or `name`) is
  left as the app wrote it.
- **The worker**: after Vite has written the site, every file it wrote is listed
  for the precache (but source maps, dot files and `skip`), the list's hash is
  the version, and the app's worker entry is bundled into `sw.js` (one IIFE file)
  with the list written in front of it.
- **Off in the desktop build**: `enabled` decides by mode; by default every mode
  but `desktop` (`vite build --mode desktop`) gets the PWA.

## The worker (`pwa-kit/sw`)

The app's worker entry:

```ts
// src/sw.ts
import { startServiceWorker } from 'pwa-kit/sw';
import config from '../pwa.config';

startServiceWorker(config, {
  notifications: { title: config.name, icon: '/icon-192.png', badge: '/favicon-32.png' },
  // runtimeHosts: ['fonts.googleapis.com', 'fonts.gstatic.com'],   // BrickBudget's fonts
  // update: 'auto',
});
```

- **A version is cached whole**: every file of the build, one cache per version,
  an unchanged hashed file carried over from the version before; one failed file
  and nothing of that version is kept (the browser tries again).
- **Navigations**: the network first, the cached `index.html` offline. A site
  built without the plugin (no precache list) keeps the last page it got as the
  shell instead, as the two trackers did.
- **Never answered, never cached**: the API and Firebase's `/__/` pages (`pass`),
  every other site (Firestore, the sign-in endpoints, Google's APIs), a request
  with a query, a file not in the build.
- **Run-time hosts**, opt-in: other sites whose files are kept for offline use
  (fonts), served from the cache and refreshed behind it, 60 at most.
- **The update flow**: `update: 'prompt'` (the default) keeps a new version
  waiting until the page asks it to take over (its Reload), so an edit in
  progress is never lost; `'auto'` takes over at once, as the trackers did.
  The older versions' caches go when the new one is active; the share and
  run-time caches stay.
- **The share target** (`shareTarget.method: 'post'`): the worker keeps the
  share (its accepted files, title, text and url) in the app's share cache and
  opens `opens`; an unreadable share opens it too.
- **Notifications**, opt-in: a push is read as `{ title, body?, tag?, url? }`
  (or by the app's `read`) and shown; a push it cannot read still shows the
  app's name (a push the browser was told is user-visible must show
  something). A tap opens the view in the app's open window, else in a new one,
  and only a path of this site.

## The page

### Update (`pwa-kit/update`)

```ts
import { registerServiceWorker, shouldRegister, updates } from 'pwa-kit/update';

if (shouldRegister({ prod: import.meta.env.PROD, mode: import.meta.env.MODE, supported: 'serviceWorker' in navigator, desktopWindow: Boolean(window.myDesktop) })) {
  window.addEventListener('load', () => void registerServiceWorker(navigator.serviceWorker));
}
// the app's update bar: useSyncExternalStore(updates.subscribe, updates.ready); its Reload button calls updates.reload()
```

An open page checks for a new version every hour. The first worker of a page
that had none is no update. After `reload()` the page reloads once the new
version controls it, never by itself.

### Install (`pwa-kit/install`)

```ts
import { IOS_STEPS, install, installOffer, placeOf } from 'pwa-kit/install';

install.listen(window);   // in the page's entry, before anything renders: Chromium fires its event once, early
// the app's entry: installOffer(placeOf(window, isDesktop), { canPrompt: install.canPrompt(), installed: install.installed() })
//   'prompt'    -> its Install button calls install.prompt() (the browser's dialog; the event is used once)
//   'ios-steps' -> it shows IOS_STEPS (Share, then Add to Home Screen) in its own language,
//                  and IOS_STEPS.noShare when the app has a share target
//   null        -> nothing: installed already, a desktop build, or a browser that offers no install
```

### Offline (`pwa-kit/offline`)

The data's offline copy is the store's: with Firestore, its persistent local
cache (`initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) })`),
cleared at sign-out (`terminate`, then `clearIndexedDbPersistence`), as SmakMal
does. The kit gives the page the rest:

- `online` (`subscribe`, `now`): the offline line reads it.
- `saved(write)`: a write the page does not wait on while offline (Firestore
  settles it only when it is sent); a write the server later refuses is
  recorded in `refusals` for the page to show.
- `needsConnection(action, reason)`: an action (an AI call) refused offline with
  the app's reason before any request is made.

### Share (`pwa-kit/share`)

- `'post'`: the page at `opens` calls `takeShare(caches, config.app)` once: the
  files, title, text and url, removed as they are read.
- `'get'`: the page at `action` reads `sharedFromQuery(location.search)` and
  replaces the address with `withoutShareQuery(location.href)`, so a reload
  does not share again.

Sharing into a web app is offered on Android and on desktop Chromium once
installed, never on iPhone or iPad.

### Notifications (`pwa-kit/push`)

`pushSupport` says whether this device can take them and why not
(`'ios-install'`: on iPhone and iPad only the app added to the Home Screen,
iOS 16.4 and later). `subscribePush` asks for permission only then (call it
from the switch the user turned on) and returns the device's subscription
(`deviceId`, `endpoint`, `p256dh`, `auth`) or `'denied'`; `endPush` ends it.
The server keeps it and sends to it with `pwa-kit/push/server` (below); what is
sent when is the app's (SmakMal: four reminders on a schedule).

## Sending notifications (`pwa-kit/push/server`)

Web Push from the app's server, Node 22 or later, no dependency (node:crypto
and fetch). Generalised from SmakMal's reminder sender (`lib/reminders`), which
keeps its own until its switch-over item.

```ts
import { firestoreSubscriptionsFromEnv, pushAll, sendPush, vapidFromEnv } from 'pwa-kit/push/server';

const vapid = vapidFromEnv(process.env);                // VAPID_PUBLIC_KEY (or VITE_VAPID_PUBLIC_KEY), VAPID_PRIVATE_KEY, VAPID_SUBJECT
const store = firestoreSubscriptionsFromEnv(process.env, { ownersUnder: 'users' });   // FIREBASE_SERVICE_ACCOUNT, ...
if ('missing' in vapid) throw new Error(`push is not set up: ${vapid.missing.join('; ')}`);
if ('missing' in store) throw new Error(`push is not set up: ${store.missing.join('; ')}`);

// the page's subscribePush answer, sent by a signed-in user
await store.save({ ...subscription, owner: uid, data: { lang: 'sv' } });

// one device
const r = await sendPush(subscription, { title: 'Dags att handla', url: '/lista' }, { vapid, ttl: 6 * 3600, topic: 'shopping' });

// every device (or one owner's: owner), the gone ones removed
const { summary } = await pushAll({
  store, push: { vapid, ttl: 6 * 3600 },
  message: (s) => ({ title: s.data.lang === 'sv' ? 'Dags att handla' : 'Time to shop' }),   // null: nothing for this one
});
```

- **The request** (RFC 8292, RFC 8291, RFC 8030): signed with the site's VAPID
  key (an ES256 JWT for the push service's origin, 12 hours, 24 at most); the
  payload encrypted for the device (aes128gcm, a new key and salt every time),
  3993 bytes at most: a string as it is, bytes as they are, anything else as
  JSON (`pwa-kit/sw` reads `{ title, body?, tag?, url? }`); `null` sends an
  empty push.
- **TTL is required**: how long, in seconds, the push service keeps a push for
  a device that is off (0: now or never). **Urgency** `very-low`, `low`,
  `normal` (the default) or `high` (a phone on battery may hold the low ones).
  **Topic** (1 to 32 of A-Z a-z 0-9 - _): a newer push with the same topic
  replaces one still waiting.
- **The result**: `sent`; `gone` (404 or 410: the subscription no longer
  exists, and `pushAll` removes it); `invalid` (not sent: not a known push
  service's https endpoint, or keys of the wrong length; kept unless
  `removeInvalid`); `failed` (with why, and `retryAfterS` when the push service
  said, as on a 429). It throws only on the sender's own mistakes: no TTL, a
  bad topic, a payload too large, a key pair that is not one.
- **Only the browsers' push services.** An endpoint comes from a page, so the
  sender posts only over https to FCM (Chrome, Android), Mozilla (Firefox),
  WNS (Edge) and Apple (Safari, iOS), `PUSH_SERVICE_HOSTS` (a subdomain
  counts); `hosts` adds others.
- **The settings come from the deploy's environment**, never from a file of
  the repository ([.env.example](.env.example) names them); what is missing or
  wrong is named, never shown. `generateVapidKeys()` makes a new pair; its
  private half goes straight into the host's secrets, and a new pair ends
  every device's subscription.
- `pushAll` keeps 4 pushes in flight (`concurrency`) and returns the counts
  (`sent`, `gone`, `invalid`, `failed`, `skipped`, the longest `retryAfterS`)
  and each device's result by its key.

### The subscription store

`SubscriptionStore` is three methods: `list(owner?)`, `save(subscription)`,
`remove(key)`. `save` checks what the page sent (`subscriptionProblems`: the
ids, the endpoint, the keys' lengths) and keeps the record's first date and the
app's own fields (`data`; SmakMal's `reminders`, `lang`, `sent`). Another
store (a SQL table, a key-value store) is those three methods.

- `memorySubscriptions()`: for tests and a local run.
- `firestoreSubscriptionsFromEnv` (or `firestoreSubscriptions` with a
  `FirestoreRest`): Firestore through its REST API, as a service account of the
  Firebase project (`FIREBASE_SERVICE_ACCOUNT`: its JSON key, or the same in
  base64; `FIREBASE_PROJECT_ID`, by default the key's; `FIREBASE_DATABASE_ID`,
  by default `(default)`), its token signed with node:crypto, no Admin SDK.
  `ownersUnder: 'users'` is SmakMal's layout,
  `users/{uid}/pushSubscriptions/{deviceId}` (its rules let only the owner
  write from the page; the server's account reads them all); without it the
  records are flat, `pushSubscriptions/{deviceId}`, the owner a field.
  `collection` renames `pushSubscriptions`.

### iPhone and iPad

- Web Push reaches only the app added to the Home Screen, on iOS and iPadOS
  16.4 and later (`pushSupport` says `'ios-install'` in Safari). The endpoint
  is Apple's (`web.push.apple.com`), which refuses a VAPID subject that is not
  `mailto:` or `https:`.
- **No silent push**: every push has to show a notification, or Safari may end
  the subscription. `pwa-kit/sw` always shows one (its `notifications.title`
  for an empty or unreadable push), so a data-only or badge-only push is not an
  option.

## The main navigation (`pwa-kit/nav`)

The user's pick at PWA.NAV-PROPOSALS (choice 1 from RQ.dfdbfc; the mockups are
in `docs/proposals/nav/`): a labelled bottom bar on the phone with a More sheet
for the overflow, never a menu button as the main navigation. The kit holds the
state; each app draws its bar, rail and top bar itself.

| Window width | `mode` | Slots (More counted) |
| --- | --- | --- |
| under 600 px | `'bar'` | 5: five destinations, or four and More |
| 600 to 1199 px | `'rail'` | 7, the labels under the icons |
| 1200 px and wider | `'top'`, or `'rail-expanded'` with `wide: 'rail-expanded'` | every destination |
| any, with fewer than two destinations | `'none'` | nothing to draw |

```ts
import { navStore } from 'pwa-kit/nav';

export const nav = navStore({
  destinations: [
    { id: 'kitchen', label: 'Kitchen', route: '/', also: ['/recipe'], icon: ChefIcon },
    { id: 'planner', label: 'Planner', route: '/planner', icon: CalendarIcon },
    // Shopping, Flavours, Doodles, Profile
  ],
  moreActions: true,        // More also holds Sign out and the AI notice
}, window);

// the app's shell (React)
const state = useSyncExternalStore(nav.subscribe, nav.now);
const { pathname, search } = useLocation();
useEffect(() => nav.go(pathname + search), [pathname, search]);
// state.mode                           which of the app's bar, rail or top bar to draw
// state.visible, more, moreShown       the links, the More sheet's links, whether More is drawn
// state.active, moreActive             aria-current="page" on its link, or on More when it is in the sheet
// state.back                           the installed window's back control: a link to state.back.up
```

- **Destinations** are the app's own objects: an icon or a count rides along
  and comes back as given. They go most important first; `priority` keeps a
  later one out of More (the lower, the longer it stays); they always show in
  list order. The store takes the ones the app has now: `nav.setDestinations`
  when that changes (BrickBudget's Wishlist once shared).
- **More takes only the overflow.** In the bar the first four by priority show
  and the rest go into More; `moreActions: true` keeps More in the bar for the
  app's own actions even when every destination fits. The rail's seven slots
  hold SmakMal's six whole; its actions go at the rail's foot.
- **The active destination** is the one whose route (or one in `also`) holds
  the location most closely, by path segments and then by query:
  `/?view=wishlist` holds only with that query and beats `/`. A destination at
  `/` holds every page no other one does. A trailing slash and the hash do not
  count.
- **Back**: in the installed window (standalone or fullscreen: no browser back
  button), on a page below a destination's own route, `back.up` is that
  destination's route, or the first destination's on a page none holds. It goes
  up rather than `history.back()`: a quick action, a notification or a share
  opens the app deep, with no history behind it. In a browser tab it is null.
- **The store** reads the width through media queries at 600 and 1200 px, so a
  resize inside one mode renders nothing, and the display mode the same way. A
  router's `pushState` fires no event: the app passes the location to `go()`.
  `navState` gives the whole state at once (a server render, a test);
  `navMode`, `navLayout`, `activeDestination` and `isTopLevel` give the pieces.
- **The checks**, `checkNav(destinations, { quickActions })` in the app's tests:
  errors for a missing or repeated id, an empty label, a route that is not a
  path of this app, one route on two destinations; warnings for a label over
  12 characters and a quick action that opens below the navigation (the
  installed app opens it with a back control).

An app with one screen (Brick Tracker) has no main navigation and needs no
`pwa-kit/nav`; its toolbar and sheets are its own.

### Drawing it

- **Labels always show**, under the icons in the bar and the rail; a 390 px
  bar's five slots read about 12 characters each.
- **Targets** are at least 24 by 24 CSS px (WCAG 2.2, 2.5.8) and aim at 44 by 44
  (Apple), the whole slot being the link.
- **Names and state**: the bar, the rail and the top bar are each a `nav` named
  "Main"; the current link has `aria-current="page"` (More has it when
  `moreActive`); More is a button with `aria-expanded` and `aria-controls`,
  and its sheet a dialog that Escape closes, focus going back to More. Whether
  the sheet is open is the app's state.
- **Safe areas**: `env(safe-area-inset-*)` is 0 unless the viewport meta has
  `viewport-fit=cover`:

  ```html
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  ```

  ```css
  .bar  { position: fixed; inset: auto 0 0 0; padding-bottom: env(safe-area-inset-bottom); }
  main  { padding-bottom: calc(64px + env(safe-area-inset-bottom)); }  /* the bar's height: nothing hides under it */
  .rail { padding-left: env(safe-area-inset-left); }                   /* a phone on its side is wide enough for the rail */
  ```

  The top needs nothing: the kit's head tags set
  `apple-mobile-web-app-status-bar-style` to `default`, so the installed app
  starts below the status bar.
- **The keyboard**: keep the viewport's `interactive-widget` at its default,
  `resizes-visual`, so the on-screen keyboard covers the bar rather than
  pushing it up over the field being typed in. `resizes-content` (Chromium)
  lifts a fixed bar above the keyboard; an app that wants it hides the bar
  while a field has focus. iPhone and iPad ignore the setting and keep the bar
  under the keyboard.

## A sign-in that lasts past an hour (`pwa-kit/session`)

Verified against lego-tracker (15 Nov 2026):

- **Firebase Authentication already lasts.** lego-tracker's
  `src/data/firebaseSession.ts` calls `getAuth`, which keeps the session in
  IndexedDB (`indexedDBLocalPersistence` first, read in firebase 12's
  `getAuth`) and renews the
  hour-long ID token by itself, so a Firebase app stays signed in until it
  signs out. What an installed app needs is the sign-in's route: a popup has
  no way back to a standalone window on iPhone and iPad. `signInRoute`,
  `authDomainFor` and `popupFallsBack` (from SmakMal's `src/lib/signIn.ts`)
  choose the redirect there, on the site's own auth domain.
- **Google API access does not.** Google Identity Services' token client gives
  an access token that ends after an hour, renewable only through a popup.
  lego-tracker's website keeps Drive access past the hour with its own server
  session (`src/data/googleWebSession.ts`, `lib/session.ts`), not with
  `firebaseSession.ts`, and so does BrickBudget's since 16 Nov 2026 (below).
  That is what the kit takes.

The page signs in with the code popup; the server exchanges the code, keeps the
refresh token sealed in an httpOnly cookie, and gives the page short-lived
access tokens for as long as Google honours the grant (six months unused).

```ts
// the page
import { DRIVE_APPDATA_SCOPE, googleWebSession } from 'pwa-kit/session';
export const session = googleWebSession({ clientId: GOOGLE_CLIENT_ID, scopes: [DRIVE_APPDATA_SCOPE], requestedWith: 'brick-tracker' });
session.subscribe((user) => render(user));          // null signed out
await session.signIn();                             // from a click
const token = await session.accessToken();          // { refresh: true } when the API refused the last one

// the server (express, desktop-kit's loopback server, a plain Node server)
import { DRIVE_APPDATA_SCOPE, sessionConfigFromEnv, sessionMiddleware } from 'pwa-kit/session/server';
app.use(sessionMiddleware({
  config: () => sessionConfigFromEnv(process.env, {
    app: 'brick-tracker', requestedWith: 'brick-tracker', requiredScopes: [DRIVE_APPDATA_SCOPE],
    names: { clientId: 'GOOGLE_CLIENT_ID', clientSecret: 'GOOGLE_CLIENT_SECRET', secret: 'SESSION_SECRET' },
  }),
}));
```

- **The cookie**: `__Host-<app>_session`, HttpOnly, Secure, SameSite=Strict,
  Path=/, 180 days; the refresh token in it sealed with AES-256-GCM under a key
  derived (HKDF-SHA256) from the session secret (32 characters or more), the
  cookie's name as additional data. A cookie sealed under another secret or app
  reads as signed out.
- **The routes** (`/api/session` by default): `GET` who is signed in; `POST
  /google` the code (the ID token checked: Google's, this client's, unexpired,
  a verified address; every required scope granted; a refresh token, or `409
  needs-consent` and the page's next click shows Google's consent screen);
  `POST /token` a fresh access token (`invalid_grant` ends the session); `POST
  /logout`. Same-site only: the app's `X-Requested-With` always and the site's
  `Origin` on a change; `no-store`; no CORS headers. Without the three settings
  they say sign-in is not set up. Rate limiting is the app's.
- **Signing out never revokes** the grant: Google ties it to the Cloud project,
  so a revoke would also cut the app's desktop and every other browser.
- The pieces alone: `seal`, `unseal`, `checkIdToken`, `isSameSiteCall`,
  `handleSessionCall` (one call in, `{ status, headers, body }` out, for a
  server with no connect-style middleware).

The server part needs a server; on a static site one serverless function
serves the four routes. **BrickBudget already has one of its own**
(budget-tracker `api/session.js` with `server/webSession.js` and the page's
`src/web/webAuth.ts`, BT.SIGNIN-LASTS): the same four routes under
`/api/session`, the refresh token sealed (AES-256-GCM, HKDF) in a
`__Host-bb_session` cookie set again on each renewal, a fresh Drive token from
`POST /token` in the old one's last minute and once more when Drive refuses
one, and Google's one-hour popup kept wherever the server's two secrets
(`GOOGLE_CLIENT_SECRET`, `SESSION_SECRET`) are not set, `npm run web:dev`
included. It differs from the kit's: it asks for `drive.file` only, so there is
no ID token and no identity; its function is plain JavaScript (the app's
TypeScript 7 has no compiler API for Vercel to compile with); its cookie and
key derivation are its own. So BrickBudget needs nothing from
`pwa-kit/session` to last past the hour. Moving it onto the kit's
`handleSessionCall` and `googleWebSession` is optional and would cost: the
identity scopes added (the kit checks an ID token), every browser signing in
once more (another cookie), and the kit installable on Vercel (a release).

## What the three apps did, and what the kit keeps

| | SmakMal | BrickBudget (budget-tracker) | Brick Tracker (lego-tracker) | The kit |
| --- | --- | --- | --- | --- |
| Manifest | written by a script from one source, checked current by a test | hand-written | hand-written | built from the config by the plugin |
| Quick actions | three, with 96 px icons | none | none | stated by every app, asked of the user |
| Precache | every file of the build, by version | a fixed shell list | none | every file of the build, by version |
| Navigations | network first, cached `index.html` | network first, cached `/` | network first, cached `/` | network first, cached shell |
| Other sites | never | Google Fonts kept | never | never, run-time hosts opt-in |
| Update | waits for the page's Reload | at once | at once | waits (`'prompt'`), `'auto'` opt-in |
| Install entry | the browser's dialog, iPhone and iPad steps | the browser's dialog | none | both |
| Share target | POST, a receipt photo through the worker | GET, a shop page's link | none | both |
| Offline edits | Firestore's local cache, `saved()` | the last copy kept | none | `saved()`, `online`, `needsConnection` |
| Notifications | four reminders, sent with web-push from Firestore's records | none | none | opt-in, sent by `pwa-kit/push/server` |
| Lasting sign-in | Firebase (lasts), redirect in the installed app | its own server session (Drive, `drive.file`), the one-hour popup where the server is not set up | server session (Drive), Firebase (lasts) | both |
| Navigation | a two-row phone header, five places as icons only | the phone's tabs (Wishlist, Recurring), desktop tabs that wrap at 1440 px | one screen | the state of a bar, a rail and a top bar |

## Adopting it in an app

The steps an app's switch-over item follows:

1. **Ask the user for the quick actions**: run `npx pwa-kit routes src`, put
   the candidates and the app's purpose to the user as one choice (four at
   most read on Android), and write the pick into `quickActions` (`[]` for
   none).
2. Write `pwa.config.ts` from the app's current manifest (name, colours, icons,
   share target), and run `checkPwaConfig` on it (the build does too).
3. Add the plugin to `vite.config.ts` with the worker entry; delete
   `public/manifest.webmanifest`, `public/sw.js` and the manifest's head tags
   the plugin now adds (keep any the app wants different: the plugin leaves
   them).
4. Write `src/sw.ts` (three lines, above) with the app's options: notifications,
   run-time hosts, `update`.
5. Replace the app's registration, install hook, online store and share reading
   with `pwa-kit/update`, `pwa-kit/install`, `pwa-kit/offline`,
   `pwa-kit/share`; its entries keep their look and words.
6. A sign-in that ends after an hour (a GIS token client): move to
   `pwa-kit/session` and its server routes. An app that already has a server
   session of its own (BrickBudget, above) keeps it; moving is optional.
7. An app with more than one main place: its destinations into `navStore`, its
   bar, rail and top bar drawn from the state (above), `viewport-fit=cover`
   added, `checkNav` in a test.
8. An app that sends notifications: its server's sender on
   `pwa-kit/push/server` (`sendPush`, or `pushAll` over its store), the
   settings `.env.example` names set in the deploy's environment.
9. Check the website build in a browser (Playwright's own launch over a pipe):
   installable, offline reload, the update bar, a share, a quick action, the
   navigation at 390, 820 and 1440 px and the installed window's back control.

## Building and testing

ESM and CommonJS builds with their types, by tsup.

```sh
npm install
npm run build       # dist/
npm run dev         # rebuilds on every change, while an app links the kit
npm test            # builds first, then runs the tests (vitest)
npm run typecheck
```

The tests include a real Vite build of a small app whose `sw.js` is then run as
a browser would (installed from the built files, a navigation answered
offline), and load the built package by its name from CommonJS and ESM, so a
broken export map fails them. The sender's tests post to a fake push service
that checks the VAPID token and decrypts the payload as a browser does (and
RFC 8291's own test vector), and run the Firestore store against a fake of
Google's token endpoint and Firestore's REST API.

## Linking it from an app

While it is developed, the app depends on the sibling folder, and
`npm run build` (or `npm run dev`) here keeps `dist/` current:

```json
"pwa-kit": "file:../pwa-kit"
```

A release is an annotated tag, `v<version>` from `package.json`, as for
desktop-kit; `dist/` is built from it, never committed. `v0.2.0` is the first,
with `pwa-kit/nav`; `v0.3.0` adds `pwa-kit/push/server`.
